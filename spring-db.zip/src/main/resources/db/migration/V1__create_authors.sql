CREATE TABLE authors_temp (
    author_id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    genre TEXT NOT NULL,
    date_of_creation DATE NOT NULL
);

INSERT INTO authors_temp (name, genre, date_of_creation) VALUES
('AC/DC', 'Rock band', '1973-11-01'),
('Led Zeppelin', 'Rock band', '1968-8-12')