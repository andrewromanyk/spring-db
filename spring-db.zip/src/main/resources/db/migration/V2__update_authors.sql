CREATE TABLE descriptions (
    desc_id SERIAL PRIMARY KEY,
    author_id SERIAL,
    full_description TEXT,
    FOREIGN KEY (author_id) REFERENCES authors_temp (author_id)
);

INSERT INTO descriptions (author_id, full_description)
SELECT author_id, CONCAT(name, 'is a', genre) FROM authors_temp