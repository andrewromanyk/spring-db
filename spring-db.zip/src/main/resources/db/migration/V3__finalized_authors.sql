CREATE SEQUENCE authors_seq START WITH 1 INCREMENT BY 50;
CREATE TABLE authors (
    author_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    date_of_creation DATE NOT NULL
);

CREATE SEQUENCE album_seq START WITH 1 INCREMENT BY 50;
CREATE TABLE album (
    album_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT
);

CREATE SEQUENCE song_seq START WITH 1 INCREMENT BY 50;
CREATE TABLE song (
    song_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    duration INT,
    author_id BIGINT NOT NULL,
    album_id BIGINT,

    CONSTRAINT fk_author FOREIGN KEY (author_id) REFERENCES authors (author_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_album FOREIGN KEY (album_id) REFERENCES album (album_id)
        ON DELETE SET NULL ON UPDATE CASCADE
);

INSERT INTO authors (name, description, date_of_creation)
SELECT a.name, d.full_description, a.date_of_creation
FROM authors_temp AS a INNER JOIN descriptions AS d ON a.author_id = d.author_id;

DROP TABLE descriptions;
DROP TABLE authors_temp;